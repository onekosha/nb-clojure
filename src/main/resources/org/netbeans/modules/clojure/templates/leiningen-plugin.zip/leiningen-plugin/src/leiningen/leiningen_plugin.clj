(ns leiningen.leiningen-plugin)

(defn leiningen-plugin
  "I don't do a lot."
  [project & args]
  (println "Hi!"))

# Introduction to clojure-library

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)

(ns leiningen.clojure-plugin)

(defn clojure-plugin
  "I don't do a lot."
  [project & args]
  (println "Hi!"))

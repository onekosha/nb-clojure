(ns com.clojurebook.histogram)

(def keywords (map keyword
                   '(w c a d b c a f s r a a c b d a a f a a a a b b b)))